﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Exercise1();
            Exercise2();
            Exercise3();
        } // end main method
        public static void Exercise1()
        {
            // display the following information on the screen: Programming is fun!!
            
            //Console.WriteLine("Hello, World!");
            Console.WriteLine("Programming is fun!!");
        } // end method
        public static void Exercise2()
        {
            //display the following information about yourself on the screen: 
            Console.WriteLine("\n");
            Console.WriteLine("My name is Rethabile");
            Console.WriteLine("My student number is 123456789");
            Console.WriteLine("I live in Bloemfontein");
            Console.WriteLine("I'm 21 years old");
        } // end method 
        public static void Exercise3()
        {
            Console.WriteLine("\n");
            Console.WriteLine("NN      NN");
            Console.WriteLine("NNNN    NN");
            Console.WriteLine("NN  NN  NN");
            Console.WriteLine("NN    NNNN");
            Console.WriteLine("NN      NN");
        } // end method
    } // end class
} // end namespace